from distutils.core import  setup
setup(
      name = 'model_b_training.py',
      version = '0.1',
      author = 'qinshuo',
      py_modules=['mymodel.model_b_training'] 
)
